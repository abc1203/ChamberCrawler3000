#ifndef SUBJECT_H
#define SUBJECT_H
#include <vector>
#include "gameobject.h"
#include "enum.h"

class Observer;

class Subject {
    std::vector<Observer*> observers;
    int row, col;
    ObjectType type;

public:
    void setRow(int newRow);
    void setCol(int newCol);
    void setObjectType(ObjectType newType);

    void attach(Observer *o);
    void notifyObservers();
    int getRow() const;
    int getCol() const;
    ObjectType getObjectType() const;
};


void Subject::attach(Observer *o) {
    observers.emplace_back(o);
}

void Subject::notifyObservers() {
    for(auto &ob : observers) ob->notify(*this);
}

void Subject::setRow(int newRow) { row = newRow; }

int Subject::getRow() const { return row; }

void Subject::setCol(int newCol) { col = newCol; }

int Subject::getCol() const { return col; }

void Subject::setObjectType(ObjectType newType) { type = newType; }

ObjectType Subject::getObjectType() const { return type; }

// std::vector<Observer*> Subject::getObservers() const { return observers; }


#endif
