#include <iostream>
#include <string>
#include <cstdlib>
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include "floor.h"
using namespace std;

Floor::Floor(string inputFile): inputFile{inputFile}, Prow{-1}, Pcol{-1}, floorEnd{false}, gameEnd{false}, td{new TextDisplay()} {
    if(inputFile != ""){ defaultFloor = false; return; }

    defaultFloor = true;
    fstream file;
    file.open("defaultFloor.txt");
    
    // add wall and door to the graph
    vector<vector<object>> bound;
    for(int k=0;k<5;++k){
        vector<object> v1;
        vector<object> v2;
        bound.push_back(v1);
        gene.push_back(v2);
    }

    char cmd;
    int row,col;
    int length;
    for(int k=0;k<5;++k){
        while(file >> cmd){
            // case of horizontal wall
            if(cmd == 'h'){
                while(file >> row){
                    if(row == -1) break;
                    file >> col >> length;
                    for(int i=0;i<length;++i){
                        object o1{row,col+i,new HWall{row,col+i}};
                        bound[k].emplace_back(o1);
                    }
                }
            }
            // case of vertical wall
            else if(cmd == 'v'){
                while(file >> row){
                    if(row == -1) break;
                    file >> col >> length;
                    for(int i=0;i<length;++i){
                        object o1{row+i,col,new VWall{row+i,col}};
                        bound[k].emplace_back(o1);
                    }
                }
            }
            // case of door
            else if(cmd == 'd'){
                while(file >> row){
                    if(row == -1) break;
                    file >> col;
                    object o1{row,col,new Door{row,col}};
                    bound[k].emplace_back(o1);
                }
            }
            // case of floor tile
            else if(cmd == 'f'){
                while(file >> row){
                    if(row == -1) break;
                    file >> col;
                    int erow,ecol;
                    file >> erow >> ecol;
                    for(int i=row;i<=erow;++i){
                        for(int j=col;j<=ecol;++j){
                            object o1{i,j,nullptr};
                            gene[k].emplace_back(o1);
                        }
                    }
                }
                break;
            }
            else cerr << "error in input";
        }
    }

    // input the passage
    // horizontal passage
    vector<object> passage;
    while(cin >> row){
        if(row == -1) break;
        cin >> col >> length;
        for(int i=0;i<length;++i){
            object o1{row,col+i,new Passage{row,col+i}};
            passage.emplace_back(o1);
        }
    }
    // vertical passage
    while(cin >> row){
        if(row == -1) break;
        cin >> col >> length;
        for(int i=0;i<length;++i){
            object o1{row+i,col,new Passage{row+i,col}};
            passage.emplace_back(o1);
        }
    }

    // initialize graph to be empty
    // vector<vector<char>> graph;
    for(int i=0;i<25;++i){
        vector<GameObject *> ob;
        // vector<char> g;
        for(int j=0;j<79;++j){
            ob.emplace_back(nullptr);
            // g.emplace_back(' ');
        }
        grid.emplace_back(ob);
        // graph.emplace_back(g);
    }
    // add the wall outside
    for(int i=0;i<25;++i){
        grid[i][0] = new VWall{i,0};
        td->notify(*grid[i][0]);
        grid[i][78] = new VWall{i,78};
        td->notify(*grid[i][78]);
        // graph[i][0] = '|';
        // graph[i][78] = '|';
    }
    for(int i=1;i<78;++i){
        grid[0][i] = new HWall{0,i};
        td->notify(*grid[0][i]);
        grid[24][i] = new HWall{24,i};
        td->notify(*grid[24][i]);
        // graph[0][i] = '-';
        // graph[24][i] = '-';
    }
    // add the wall and door to the graph
    for(int k=0;k<5;++k){
        for(auto ob : bound[k]){
            grid[ob.row][ob.col] = ob.type;
            // graph[ob.row][ob.col] = ob.type;
        }
        // for(auto ob : gene[k]){
        //     grid[ob.row][ob.col] = ob.type;
        //     graph[ob.row][ob.col] = ob.type;
        // }
        // bound[k].clear();
    }
    // bound.clear();

    for(auto ob: passage){
        grid[ob.row][ob.col] = ob.type;
        // graph[ob.row][ob.col] = ob.type;
    }

    cgene = gene;

    // textdisplay binding

}

Floor::~Floor() {
    for(auto vec: grid){
        for(auto ob: vec){
            delete ob;
        }
    }
    delete player;
    delete td;
}

void Floor::newFloor(bool barrierSuit){
    
    // didn't address barrierSuit and dragon and compass
    // directly input from file if file is given
    if(!defaultFloor){
        fstream file;
        file.open(inputFile);
        bool ifPlayer = false;
        char c;
        vector<ObjectType> potion;
        vector<ObjectType> enemys;
        vector<ObjectType> Golds;
        // better add an detection to notice player if their map is invalid
        // ex: player/stairs didn't exist
        // the map didn't start from the first line.
        for(int i=0;i<25;++i){
            for(int j=0;j<79;++j){
                if(!(file >> c)){ cerr << "invalid map" << endl; return; }
                if(c == '-') grid[i][j] = new HWall{i,j};
                else if(c == '|') grid[i][j] = new VWall{i,j};
                else if(c == '+') grid[i][j] = new Door{i,j};
                else if(c == '#') grid[i][j] = new Passage{i,j};
                else if(c == '.') grid[i][j] = new Tile{i,j};
                else if(c == '\\') grid[i][j] = new Stairs{i,j};
                else if(c == 'P') grid[i][j] = randomPotion(i,j);
                else if(c == 'G') grid[i][j] = randomTreasure(i,j);
                else if(c == 'C') grid[i][j] = new Compass{i,j};
                else if(c == 'B') grid[i][j] = new BarrierSuit{i,j};
                else if(c == 'V') grid[i][j] = new Vampire{i,j};
                else if(c == 'W') grid[i][j] = new Werewolf{i,j};
                else if(c == 'N') grid[i][j] = new Goblin{i,j};
                else if(c == 'M') grid[i][j] = new Merchant{i,j};
                else if(c == 'D') grid[i][j] = new Dragon{i,j};
                else if(c == 'X') grid[i][j] = new Phoenix{i,j};
                else if(c == 'T') grid[i][j] = new Troll{i,j};
                else if(c == '@'){ Prow = i; Pcol = j; }
                else {
                    cerr << "Invalid Input Char in Map : " << c << endl;
                    return;
                }
                grid[i][j]->attach(td);
            }
        }
        return;
    }

    // generate the dragon neer the barrierSuit and Dragon Horde

    // Or random generate the barrierSuit / compass somewhere

    // romoving old object (stuff inside the chamber)
    for(auto vec:gene){
        for(auto ob:vec){
            if(grid[ob.row][ob.col]->getObjectType() != ObjectType::Player){
                delete grid[ob.row][ob.col];
            }
            grid[ob.row][ob.col] = nullptr;
        }
    }

    // adding new object

    // start generation

    int enemy = 20; // number of enemy needs to be generate
    int row, col;

    // shuffle all the title in each chamber
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine rng{seed};
    for(int k=0;k<5;++k) shuffle( gene[k].begin(), gene[k].end(), rng );

    int p;
    // generate player's position
    std::srand(time(0));
    p = rand()%5; 
    Prow = gene[p][0].row;
    Pcol = gene[p][0].col;
    grid[Prow][Pcol] = player;
    // graph[Prow][Pcol] = '@';
    gene[p].erase(gene[p].begin());

    // generate stair's position
    p = rand()%5;
    row = gene[p][0].row;
    col = gene[p][0].col;
    int stairRow = row;
    int stairCol = col;
    grid[row][col] = new Stairs(row,col);
    grid[row][col]->attach(td);
    // graph[gene[p][0].row][gene[p][0].col] = '\\';
    gene[p].erase(gene[p].begin());

    // generate barrierSuit's position
    if(barrierSuit){
        p = rand()%5;
        row = gene[p][0].row;
        col = gene[p][0].col;
        grid[row][col] = new BarrierSuit(row,col);
        grid[row][col]->attach(td);
        // graph[gene[p][0].row][gene[p][0].col] = '\\';
        int brow = gene[p][0].row;
        int bcol = gene[p][0].col;
        gene[p].erase(gene[p].begin());

        Dragon* dragon = geneDragon(p,brow,bcol);
        dragon->setTreasure(dynamic_cast<GameObject*>(grid[gene[p][0].row][gene[p][0].col]));

        --enemy;
    }

    // generate potion
    for(int k=0;k<5;++k){
        p = rand()%5;
        if(p != 0) continue; // 1/5 chance
        // Note index is k instead of p is because one each chamber
        row = gene[p][0].row;
        col = gene[p][0].col;
        grid[row][col] = randomPotion(row,col);
        grid[row][col]->attach(td);
        // int q = rand()%6; // type of potion: 1/6 chance each
        // graph[gene[p][0].row][gene[p][0].col] = 'P';
        gene[p].erase(gene[p].begin());
    }
    
    // generate treasure
    for(int k=0;k<10;++k){
        p = rand()%5;
        int grow = gene[p][0].row;
        int gcol = gene[p][0].col;
        Treasure* treasure = randomTreasure(grow,gcol);
        int value = treasure->getValue();
        grid[grow][gcol] = treasure;
        grid[grow][gcol]->attach(td);
        //generate dragon to garde for dragon hoard
        // int q = rand()%8; // type of treasure: 5/8 normal, 1/8 dragon hoard, 1/4 small horde
        // graph[gene[p][0].row][gene[p][0].col] = 'G';
        gene[p].erase(gene[p].begin());
        if(value == 6){
            Dragon* dragon = geneDragon(p,grow,gcol);
            dragon->setTreasure(dynamic_cast<GameObject*>(grid[gene[p][0].row][gene[p][0].col]));
            --enemy;
        }
    }
    
    // generate enemy
    int compass = rand()%enemy;
    for(int k=0;k<enemy;++k){
        p = rand()%5;
        row = gene[p][0].row;
        col = gene[p][0].col;
        grid[row][col] = randomEnemy(row,col);
        grid[row][col]->attach(td);

        if(k == compass) {
            Compass* compass = new Compass(row,col);
            compass->attach(grid[stairRow][stairCol]);
            // grid[row][col]->attach(compass);
        } // bind the compass to the enemy
        
        // int q = rand()%18; // type of enemy: Werewolf: 2/9, Vampire: 3/18, Goblin: 5/18, Troll: 1/9, Phoenix: 1/9, Merchant: 1/9
        // if(0 <= q && q < 4) graph[gene[p][0].row][gene[p][0].col] = 'W';
        // else if(4 <= q && q < 7) graph[gene[p][0].row][gene[p][0].col] = 'V';
        // else if(7 <= q && q < 12) graph[gene[p][0].row][gene[p][0].col] = 'N';
        // else if(12 <= q && q < 14) graph[gene[p][0].row][gene[p][0].col] = 'T';
        // else if(14 <= q && q < 16) graph[gene[p][0].row][gene[p][0].col] = 'X';
        // else if(16 <= q && q < 18) graph[gene[p][0].row][gene[p][0].col] = 'M';
        gene[p].erase(gene[p].begin());

    }

    // fill the rest with floor tile;
    for(int k=0;k<5;++k){
        for(auto ob: gene[k]){
            grid[ob.row][ob.col] = new Tile{ob.row,ob.col};
            grid[ob.row][ob.col]->attach(td);
        }
    }

    // refreshing the gene to be cgene
    gene = cgene;
}


void Floor::raceSelect(char c) {
    if(c == 'h') player = new Human{Prow,Pcol};
    else if(c == 'e') player = new Elves{Prow,Pcol};
    else if(c == 'd') player = new Dwarf{Prow,Pcol};
    else if(c == 'o') player = new Orc{Prow,Pcol};
    else cerr << "Incorrect Race Selection" << endl;
    player->attach(td);
}

GameObject* Floor::getDestination(Direction s) {
    int destRow, destCol;
    // finds the expected destination
    if(s == Direction::NO) { // north
        destRow = player->getRow() - 1; destCol = player->getCol();
    } else if(s == Direction::SO) { // south
        destRow = player->getRow() + 1; destCol = player->getCol();
    } else if(s == Direction::EA) { // east
        destRow = player->getRow(); destCol = player->getCol() + 1;
    } else if(s == Direction::WE) { // west
        destRow = player->getRow(); destCol = player->getCol() - 1;
    } else if(s == Direction::NE) { // northeast
        destRow = player->getRow() - 1; destCol = player->getCol() + 1;
    } else if(s == Direction::NW) { // northwest
        destRow = player->getRow() - 1; destCol = player->getCol() - 1;
    } else if(s == Direction::SE) { // southeast
        destRow = player->getRow() + 1; destCol = player->getCol() + 1;
    } else if(s == Direction::SW) { // southwest
        destRow = player->getRow() + 1; destCol = player->getCol() - 1;
    }

    if((destRow >= 0 && destRow < grid.size()) && (destCol >= 0 && destCol < grid[destRow].size())) {
        ObjectType type = grid[destRow][destCol]->getObjectType();

        if(type != ObjectType::HWall && type != ObjectType::VWall && 
           type != ObjectType::Potion && type != ObjectType::Enemy && type != ObjectType::Player) {
            return grid[destRow][destCol];
        }
    }
    return nullptr;
}


// player moves; return false if the move is invalid
bool Floor::move(Direction s) {
    GameObject* destination = getDestination(s);

    if(destination != nullptr && 
    (destination->getObjectType() != ObjectType::HWall && destination->getObjectType() != ObjectType::VWall &&
    destination->getObjectType() != ObjectType::Potion && destination->getObjectType() != ObjectType::Enemy && 
    destination->getObjectType() != ObjectType::Player)) { // player moves

        if((destination->getObjectType() == ObjectType::Treasure && !(dynamic_cast<Treasure*>(destination)->isAvailable())) ||
           (destination->getObjectType() == ObjectType::BarrierSuit && !(dynamic_cast<BarrierSuit*>(destination)->isAvailable()))) {
            return false;
        } else {
            player->getPrevious()->notify(dynamic_cast<Subject&>(*player)); // set up the location for the tile player was holding
            grid[player->getRow()][player->getCol()] = player->getPrevious(); // drops the original tile on the grid
            
            // player moves
            player->setPrevious(destination);
            player->setRow(destination->getRow());
            player->setCol(destination->getCol());
            grid[player->getRow()][player->getCol()] = player;

            // player stepped on an available horde/barrier suit/compass => pick it up
            ObjectType type = player->getPrevious()->getObjectType();
            if(type == ObjectType::Treasure || type == ObjectType::BarrierSuit || type == ObjectType::Compass) {
                player->notify(*(player->getPrevious())); // player picks up the item
                player->getPrevious()->notifyObservers(); // the picked up item notifies
                delete player->getPrevious(); // deletes the item
                player->setPrevious(new Tile{-1, -1}); // sets a new tile
                player->getPrevious()->attach(td);
            }

            // player stepped on the stairs => immediately goes to the next floor
            if(type == ObjectType::Stairs) {
                floorEnd = true;
            }

            return true;
        }
    }
    return false;
}


// player drinks the potion; return false if the action is invalid
bool Floor::potion(Direction s) {
    GameObject* target = getDestination(s);

    if(target != nullptr && target->getObjectType() == ObjectType::Potion) {
        // player drinks the potion
        Potion* potion = dynamic_cast<Potion*>(target);
        player->setPotion(potion);

        // potion disappears
        int prow = potion->getRow(); int pcol = potion->getCol();
        grid[prow][pcol] = new Tile{prow,pcol};
        grid[prow][pcol]->attach(td);
        delete potion;
    }
}

// player attacks; return false if the attack is invalid
bool Floor::attack(Direction s) {
    GameObject* target = getDestination(s);

    if(target != nullptr && target->getObjectType() == ObjectType::Enemy) {
        // player attacks the enemy
        Enemy* enemy = dynamic_cast<Enemy*>(target);
        player->attack(*enemy);

        // makes all merchants hostile if player attacked a merchant
        if(enemy->getEnemyType() == EnemyType::Merchant) {
            Merchant* merchant = dynamic_cast<Merchant*>(enemy);
            merchant->setMerchantHostile(true);
        }

        // player kills the enemy
        if(!(enemy->isAlive())) {
            enemy->getPrevious()->notify(dynamic_cast<Subject&>(*enemy)); // enemy disappears from the floor
            grid[enemy->getRow()][enemy->getCol()] = enemy->getPrevious();
            player->notify(*enemy); // player collects gold from enemy death

            // merchant drops a gold horde upon death
            if(enemy->getEnemyType() == EnemyType::Merchant) { 
                int row = enemy->getRow(); int col = enemy->getCol();
                delete grid[row][col]; // deletes the old tile on the floor
                grid[row][col] = new Treasure{row, col, 4}; // puts merchant horde on the floor
                grid[row][col]->attach(td);
            } 
            // if enemy is a dragon, notifies its treasure so that it can be picked up
            enemy->notifyObservers();
            
            if(enemy->getCompass() != nullptr) { // the killed enemy is the holder of the compass => drops the compass
                int row = enemy->getRow(); int col = enemy->getCol();
                enemy->getCompass()->setRow(row); enemy->getCompass()->setCol(col);
                delete grid[row][col]; // deletes the old tile on the floor
                grid[row][col] = enemy->getCompass(); // places the compass on the floor
            } 
            delete enemy;
        }   
        return true;
    }
    return false;
}

// enemies performs action one-by-one
void Floor::gameTurn() {
    for(int i = 0; i < grid.size(); ++i) {
        for(int j = 0; j < grid[i].size(); ++j) {
            if(grid[i][j]->getObjectType() == ObjectType::Enemy) {
                Enemy* enemy = dynamic_cast<Enemy*>(grid[i][j]);
                enemyTurn(enemy, i, j);
            }
        }
    }
}

// an individual enemy performs action
void Floor::enemyTurn(Enemy* enemy, int row, int col) {
    PlayerRace* player;

    // check if player is nearby; set hostile to true in that case
    for(int i = row-1; i <= row+1; ++i) {
        for(int j = col-1; j <= col+1; ++j) {
            if((i >= 0 && i < grid.size()) && (j >= 0 && j <= grid[i].size()) && grid[i][j]->getObjectType() == ObjectType::Player) {
                player = dynamic_cast<PlayerRace*>(grid[i][j]);
                enemy->setHostile(true);
            }
        }
    }

    // attacks player if hostile, move randomly otherwise
    if(enemy->isHostile()) {
        if(!(enemy->getEnemyType() == EnemyType::Merchant && (dynamic_cast<Merchant*>(enemy))->getMerchantHostile() == false))
        enemy->attack(*player);

        // enemy kills the player => game ends
        if(!(player->isAlive())) {
            gameEnd = true;
            return;
        }
    } else {
        // finds the available destinations
        std::vector<GameObject*> possibleDestinations;
        for(int i = row-1; i <= row+1; ++i) {
            for(int j = col-1; j <= col+1; ++j) {
                if(grid[i][j]->getObjectType() == ObjectType::Tile) {
                    possibleDestinations.emplace_back(grid[i][j]);
                }
            }
        }
        
        // randomly chooses a destination using shuffle
        unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
        std::default_random_engine rng{seed};
        for(int i = 0; i < 1000; ++i) {
            std::shuffle(possibleDestinations.begin(), possibleDestinations.end(), rng);
        }

        // performs the move
        enemy->getPrevious()->notify(dynamic_cast<Subject&>(*enemy)); // drops the tile at the original location
        grid[enemy->getRow()][enemy->getCol()] = enemy->getPrevious();

        enemy->setPrevious(possibleDestinations[0]); // picks up the new tile
        enemy->setRow(possibleDestinations[0]->getRow()); // updates row location for enemy
        enemy->setCol(possibleDestinations[0]->getCol()); // updates col location for enemy
        grid[enemy->getRow()][enemy->getCol()] = enemy;
    }
}

Potion* Floor::randomPotion(int row, int col){
    // type of potion: 1/6 chance each
    Potion* potion;
    std::srand(time(0));
    int p = rand()%6;
    if(p == 0) potion = new RH{row,col};
    else if(p == 1) potion = new PH{row,col};
    else if(p == 2) potion = new BA{row,col};
    else if(p == 3) potion = new BD{row,col};
    else if(p == 4) potion = new WA{row,col};
    else if(p == 5) potion = new WD{row,col};
    else cerr << "Incorrect random Potion" << endl;
    return potion;
}

Treasure* Floor::randomTreasure(int row, int col){
    // type of treasure: 5/8 normal, 1/8 dragon hoard, 1/4 small horde
    Treasure* treasure;
    std::srand(time(0));
    int p = rand()%8;
    if(0 <= p && p < 5) treasure = new Treasure{row,col,1};
    else if(5 <= p && p < 6) treasure = new Treasure{row,col,6};
    else if(6 <= p && p < 8) treasure = new Treasure{row,col,2};
    else cerr << "Incorrect random Treasure" << endl;
    return treasure;
}

Enemy* Floor::randomEnemy(int row, int col){
    // type of enemy: Werewolf: 2/9, Vampire: 3/18, Goblin: 5/18, Troll: 1/9, Phoenix: 1/9, Merchant: 1/9
    Enemy* enemy;
    std::srand(time(0));
    int p = rand()%18;
    if(0 <= p && p < 4) enemy = new Werewolf{row,col};
    else if(4 <= p && p < 7) enemy = new Vampire{row,col};
    else if(7 <= p && p < 12) enemy = new Goblin{row,col};
    else if(12 <= p && p < 14) enemy = new Troll{row,col};
    else if(14 <= p && p < 16) enemy = new Phoenix{row,col};
    else if(16 <= p && p < 18) enemy = new Merchant{row,col};
    else cerr << "Incorrect random Enemy" << endl;
    return enemy;
}

Dragon* Floor::geneDragon(int chamber, int row, int col){
    // generate dragon to guard
    vector<object> availabe; // available for dragon
    for (auto ob = gene[chamber].begin(); ob != gene[chamber].end();){
        if(abs(row - ob->row) <= 1 && abs(col - ob->col) <= 1){
            ob = gene[chamber].erase(ob);
            availabe.push_back(*ob);
        }
        else{
            ++ob;
        }
    }
    int q = rand() % availabe.size();
    int drow = availabe[q].row;
    int dcol = availabe[q].col;
    grid[drow][dcol] = new Dragon{drow,dcol};
    grid[drow][dcol]->attach(td);
    grid[drow][dcol]->attach(grid[row][col]);
    
    availabe.erase(availabe.begin()+q);
    for(auto ob:availabe){
        gene[chamber].push_back(ob);
    }
    
    return dynamic_cast<Dragon*>(grid[drow][dcol]);
}

void Floor::printTest(){
    for(auto r: graph){
        for(auto c: r){
            cout << c;
        }
        cout << endl;
    }
}

bool Floor::getFloorEnd() { return floorEnd; }

bool Floor::getGameEnd() { return gameEnd; }

int Floor::getPlayerScore() { return player->getScore(); }

