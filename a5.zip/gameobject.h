#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H
#include <vector>
#include "subject.h"
#include "observer.h"
#include "textdisplay/textdisplay.h"
#include "enum.h"

class GameObject: public Subject, public Observer {
    // row, col, ObjectType is in Subject

public:
    GameObject(int row, int col, ObjectType type);
    virtual ~GameObject();

    virtual void notify(Subject &whoFrom) = 0;
};

#endif
