#ifndef FLOOR_H
#define FLOOR_H
#include <fstream>
#include <string>
#include <vector>
#include "textdisplay/textdisplay.h"
#include "gameobject.h"
#include "GameObject/character.h"
#include "GameObject/Character/playerrace.h"
#include "GameObject/Character/Playerrace/dwarf.h"
#include "GameObject/Character/Playerrace/elves.h"
#include "GameObject/Character/Playerrace/human.h"
#include "GameObject/Character/Playerrace/orc.h"
#include "GameObject/Character/enemy.h"
#include "GameObject/Character/Enemy/dragon.h"
#include "GameObject/Character/Enemy/goblin.h"
#include "GameObject/Character/Enemy/merchant.h"
#include "GameObject/Character/Enemy/phoenix.h"
#include "GameObject/Character/Enemy/troll.h"
#include "GameObject/Character/Enemy/vampire.h"
#include "GameObject/Character/Enemy/werewolf.h"
#include "GameObject/potion.h"
#include "GameObject/Potion/RH.h"
#include "GameObject/Potion/PH.h"
#include "GameObject/Potion/BA.h"
#include "GameObject/Potion/BD.h"
#include "GameObject/Potion/WA.h"
#include "GameObject/Potion/WD.h"
#include "GameObject/mapcomponent.h"
#include "GameObject/MapComponent/hwall.h"
#include "GameObject/MapComponent/vwall.h"
#include "GameObject/MapComponent/door.h"
#include "GameObject/MapComponent/passage.h"
#include "GameObject/MapComponent/tile.h"
#include "GameObject/MapComponent/stairs.h"
#include "GameObject/treasure.h"
#include "GameObject/compass.h"
#include "GameObject/barriersuit.h"

struct object{
    int row,col;
    GameObject *type;
    // char type;
};

class Floor {
    std::vector<std::vector<GameObject*>> grid;
    std::vector<std::vector<char>> graph;
    bool defaultFloor;
    std::string inputFile;
    // vector<vector<object>> cbound; // const, could be deleted
    std::vector<std::vector<object>> cgene; // const, used for newfloor, romoving odd and adding new
    std::vector<std::vector<object>> gene;
    int Prow, Pcol; // player's row and col
    TextDisplay *td; // textdisplay
    // list of observer of player needs to be updated each turn
    // including which object is in which direction
    PlayerRace *player;
    bool floorEnd, gameEnd;
protected:
    GameObject* getDestination(Direction s); // returns player's selected destination; returns nullptr if the direction is invalid

public:
    Floor(std::string inputFile);
    ~Floor();

    void newFloor(bool barrierSuit);

    void raceSelect(char c);

    // invoke when player's action are valid
    // update the move first, then
    // update the list of observer, attach and detach when neccersary
    void newTurn();

    // following function return false if action is invalid
    // notify player when action is invalid
    bool move(Direction s);
    bool potion(Direction s);
    bool attack(Direction s);


    void gameTurn(); // enemies perform actions one by one
    void enemyTurn(Enemy* enemy, int row, int col); // a specific enemy performs actions

    void reset();
    void display();
    void printTest();

    // function for generating special stuff
    Potion* randomPotion(int row, int col);
    Treasure* randomTreasure(int row, int col);
    Enemy* randomEnemy(int row, int col);
    Dragon* geneDragon(int chamber, int row, int col);

    bool getFloorEnd();
    bool getGameEnd();
    int getPlayerScore();
};

#endif
