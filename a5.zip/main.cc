#include <iostream>
#include <string>
#include "game.h"
using namespace std;


int main(int argc, char *argv[]) {
    string inputFile = "";
    if(argc > 1)inputFile = argv[1];
    
    Game g(inputFile);

    g.play();
    // Floor f;
    // f.printTest();
}