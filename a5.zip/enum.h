#ifndef ENUM_H
#define ENUM_H
#include <iostream>
#include <string>

enum class Direction { NO, SO, EA, WE, NE, NW, SE, SW };
enum class ObjectType { HWall, VWall, Door, Passage, Tile, Stairs, Potion, Treasure, Compass, BarrierSuit, Enemy, Player };
enum class EnemyType { Vampire, Werewolf, Goblin, Merchant, Dragon, Phoenix, Troll };
enum class PotionType { RH, BA, BD, PH, WA, WD };

std::ostream &operator<<(std::ostream &out, const ObjectType &ob){
    std::string s;
    if(ob == ObjectType::HWall) s = "HWall";
    if(ob == ObjectType::VWall) s = "VWall";
    else if(ob == ObjectType::Door) s = "Door";
    else if(ob == ObjectType::Passage) s = "Passage";
    else if(ob == ObjectType::Tile) s = "Tile";
    else if(ob == ObjectType::Potion) s = "Potion";
    else if(ob == ObjectType::Treasure) s = "Treasure";
    else if(ob == ObjectType::Compass) s = "Compass";
    else if(ob == ObjectType::BarrierSuit) s = "BarrierSuit";
    else if(ob == ObjectType::Enemy) s = "Enemy";
    else if(ob == ObjectType::Player) s = "Player";
    std::cout << s << std::endl;
}

#endif ENUM_H
