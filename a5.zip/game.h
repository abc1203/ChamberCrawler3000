#ifndef GAME_H
#define GAME_H
#include <iostream>
#include <fstream>
#include <string>
#include "floor.h"
#include "enum.h"
using namespace std;

class Game {
    Floor *floor;
    string inputFile;
    int barrierSuit;
    bool isDirection(string cmd);
    Direction getDirection(string cmd);
public:
    Game(string inputFile);
    ~Game();
    void play();
};

#endif
