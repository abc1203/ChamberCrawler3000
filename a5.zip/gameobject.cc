#include "gameobject.h"

GameObject::GameObject(int row, int col, ObjectType type) {
    setRow(row);
    setCol(col);
    setObjectType(type); // defines type for Subject
    setType(type); // defines type for Observer
}

GameObject::~GameObject() {}
