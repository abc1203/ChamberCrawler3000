#include <cstdlib>
#include "game.h"

Game::Game(string inputFile) : floor{nullptr}, inputFile{inputFile} {
    srand(time(0));
    barrierSuit = rand()%5;
}

Game::~Game() { delete floor; }

void Game::play() {
    std::cin.exceptions(ios::eofbit|ios::failbit);
    string cmd, dir;
    try {
        // choosing Character
        floor = new Floor(inputFile);
        char race;
        cout << "Please choose your Character:" << endl;
        cout << "Character   HP      Atk     Def     Specialt" << endl;
        cout << "h: Human  140 HP  20 Atk  20 Def  No special skills." << endl;
        cout << "e: Elves  140 HP  30 Atk  10 Def  Negative potions have positive effect" << endl;
        cout << "d: Dwarf  100 HP  20 Atk  30 Def  Gold is doubled in value" << endl;
        cout << "o: Orc    180 HP  30 Atk  25 Def  Gold is worth half value" << endl;
        cout << "Input one of following: h,e,d,o" << endl;
        while(cin >> race){
            if(race == 'h' || race == 'e' || race == 'd' || race == 'o') break;
            cout << "Invalid choose of Character!" << endl;
            cout << "Please input one of following: h,e,d,o" << endl;
        }
        floor->raceSelect(race);

        for(int k=0;k<5;++k){
            bool bs = (k == barrierSuit);
            floor->newFloor(bs);

            while(true) {
                floor->display();

                cin >> cmd;
                if(isDirection(cmd)) {
                    floor->move(getDirection(cmd));
                } else if(cmd == "u") {
                    cin >> dir; 
                    if(isDirection(dir)) floor->potion(getDirection(dir));
                } else if(cmd == "a") {
                    cin >> dir; 
                    if(isDirection(dir)) floor->attack(getDirection(dir));
                } else if(cmd == "r") {
                    floor->reset();
                } else if(cmd == "q") {
                    break; // might be OK to change to return
                }

                floor->newTurn();

                // if floor ends
                if(floor->getFloorEnd()) {
                    std::cout << "You have passed this floor." << std::endl;
                    break;
                }

                // if game ends
                if(floor->getGameEnd()) {
                    std::cout << "Game has ended. Your score is: " << floor->getPlayerScore() << std::endl;
                    return;
                }
            }
        }
        std::cout << "Game has ended. Your score is: " << floor->getPlayerScore() << std::endl;
        
        
    } catch(ios::failure &) {} // Any I/O failure quits
}

bool isDirection(string cmd) {
    if(cmd == "no" || cmd == "so" || cmd == "ea" || cmd == "we" || cmd == "ne" || cmd == "nw" || cmd == "se" || cmd == "sw") return true;
    return false;
}

Direction getDirection(string cmd) {
    if(cmd == "no") {
        return Direction::NO;
    } else if(cmd == "so") {
        return Direction::SO;
    } else if(cmd == "ea") {
        return Direction::EA;
    } else if(cmd == "we") {
        return Direction::WE;
    } else if(cmd == "ne") {
        return Direction::NE;
    } else if(cmd == "nw") {
        return Direction::NW;
    } else if(cmd == "se") {
        return Direction::SE;
    } else if(cmd == "sw") {
        return Direction::SW;
    }
}






